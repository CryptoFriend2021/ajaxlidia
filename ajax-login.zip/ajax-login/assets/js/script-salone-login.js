(function($) {
    $(document).ready(function() {

        // ** Gestione del Form di Login **
        $('#salone-login-form').submit(function(e) {
            e.preventDefault(); // Previeni il submit standard del form

            var form = $(this);
            var messageDiv = $('#salone-login-message');
            messageDiv.removeClass('success error').text(''); // Resetta i messaggi precedenti

            $.ajax({
                url: salone_ajax_params.ajax_url, // URL per admin-ajax.php (passato da wp_localize_script)
                type: 'POST',
                data: {
                    action: 'salone_login_action', // Nome dell'azione AJAX (definito in PHP)
                    nonce: salone_ajax_params.nonce, // Nonce per sicurezza
                    username: form.find('#salone-login-username').val(),
                    password: form.find('#salone-login-password').val()
                },
                dataType: 'json', // Aspettati una risposta JSON
                beforeSend: function() {
                    form.find('button[type="submit"]').prop('disabled', true); // Disabilita il pulsante durante la richiesta
                    messageDiv.text('Caricamento...'); // Messaggio di caricamento
                },
                success: function(response) {
                    form.find('button[type="submit"]').prop('disabled', false); // Riabilita il pulsante
                    if (response.success) {
                        messageDiv.addClass('success').text(response.data.message); // Mostra messaggio di successo
                        if (response.data.redirect_url) {
                            window.location.href = response.data.redirect_url; // Reindirizza se presente URL
                        }
                    } else {
                        messageDiv.addClass('error').text(response.data.message); // Mostra messaggio di errore
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    form.find('button[type="submit"]').prop('disabled', false); // Riabilita il pulsante
                    messageDiv.addClass('error').text('Errore durante la richiesta AJAX: ' + textStatus + ' - ' + errorThrown); // Messaggio di errore generico
                }
            });
        });


        // ** Gestione del Form di Registrazione **
        $('#salone-registrazione-form').submit(function(e) {
            e.preventDefault(); // Previeni il submit standard del form

            var form = $(this);
            var messageDiv = $('#salone-registrazione-message');
            messageDiv.removeClass('success error').text(''); // Resetta i messaggi precedenti

            $.ajax({
                url: salone_ajax_params.ajax_url, // URL per admin-ajax.php (passato da wp_localize_script)
                type: 'POST',
                data: {
                    action: 'salone_registrazione_action', // Nome dell'azione AJAX (definito in PHP)
                    nonce: salone_ajax_params.nonce, // Nonce per sicurezza
                    username: form.find('#salone-registrazione-username').val(),
                    email: form.find('#salone-registrazione-email').val(),
                    password: form.find('#salone-registrazione-password').val(),
                    password2: form.find('#salone-registrazione-password2').val()
                },
                dataType: 'json', // Aspettati una risposta JSON
                beforeSend: function() {
                    form.find('button[type="submit"]').prop('disabled', true); // Disabilita il pulsante durante la richiesta
                    messageDiv.text('Caricamento...'); // Messaggio di caricamento
                },
                success: function(response) {
                    form.find('button[type="submit"]').prop('disabled', false); // Riabilita il pulsante
                    if (response.success) {
                        messageDiv.addClass('success').text(response.data.message); // Mostra messaggio di successo
                        if (response.data.redirect_url) {
                            window.location.href = response.data.redirect_url; // Reindirizza se presente URL
                        }
                    } else {
                        messageDiv.addClass('error').text(response.data.message); // Mostra messaggio di errore
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    form.find('button[type="submit"]').prop('disabled', false); // Riabilita il pulsante
                    messageDiv.addClass('error').text('Errore durante la richiesta AJAX: ' + textStatus + ' - ' + errorThrown); // Messaggio di errore generico
                }
            });
        });

    });
})(jQuery);
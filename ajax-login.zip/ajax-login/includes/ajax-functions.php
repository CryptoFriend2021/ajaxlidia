<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Esci se viene acceduto direttamente
}

// ** Funzione per gestire la richiesta AJAX di Login **
add_action( 'wp_ajax_salone_login_action', 'salone_login_ajax_handler' ); // Per utenti loggati
add_action( 'wp_ajax_nopriv_salone_login_action', 'salone_login_ajax_handler' ); // Per utenti non loggati
function salone_login_ajax_handler() {
    // Verifica del Nonce per sicurezza
    check_ajax_referer( 'salone_login_nonce', 'nonce' );

    $username = sanitize_user( $_POST['username'] );
    $password = $_POST['password']; // NON sanitizzare la password qui!

    $creds = array();
    $creds['user_login']    = $username;
    $creds['user_password'] = $password;
    $creds['remember']      = true; // o false, a seconda delle tue preferenze

    $user = wp_signon( $creds, false ); // Effettua il login con wp_signon

    if ( is_wp_error( $user ) ) {
        // Errore di login
        wp_send_json_error( array( 'message' => $user->get_error_message() ) );
    } else {
        // Login avvenuto con successo
        wp_send_json_success( array( 'message' => 'Login effettuato con successo!', 'redirect_url' => home_url() ) ); // Puoi reindirizzare dove vuoi
    }

    wp_die(); // Importante: Termina l'esecuzione di WordPress dopo la risposta AJAX
}


// ** Funzione per gestire la richiesta AJAX di Registrazione **
add_action( 'wp_ajax_salone_registrazione_action', 'salone_registrazione_ajax_handler' ); // Per utenti loggati e non loggati (in genere solo non loggati si registrano)
add_action( 'wp_ajax_nopriv_salone_registrazione_action', 'salone_registrazione_ajax_handler' ); // Per utenti non loggati
function salone_registrazione_ajax_handler() {
    // Verifica del Nonce per sicurezza
    check_ajax_referer( 'salone_login_nonce', 'nonce' ); // Usa lo stesso nonce per semplicità, ma potresti crearne uno specifico

    $username  = sanitize_user( $_POST['username'] );
    $email     = sanitize_email( $_POST['email'] );
    $password  = $_POST['password']; // NON sanitizzare la password qui!
    $password2 = $_POST['password2']; // NON sanitizzare la password qui!

    // Validazione lato server (esempio base - aggiungi controlli più robusti)
    if ( username_exists( $username ) ) {
        wp_send_json_error( array( 'message' => 'Username già esistente.' ) );
    }
    if ( ! is_email( $email ) ) {
        wp_send_json_error( array( 'message' => 'Email non valida.' ) );
    }
    if ( email_exists( $email ) ) {
        wp_send_json_error( array( 'message' => 'Email già registrata.' ) );
    }
    if ( $password !== $password2 ) {
        wp_send_json_error( array( 'message' => 'Le password non corrispondono.' ) );
    }
    if ( strlen( $password ) < 6 ) { // Esempio: password minima di 6 caratteri
        wp_send_json_error( array( 'message' => 'La password deve essere di almeno 6 caratteri.' ) );
    }

    $user_id = wp_create_user( $username, $password, $email ); // Crea l'utente

    if ( is_wp_error( $user_id ) ) {
        // Errore di registrazione
        wp_send_json_error( array( 'message' => $user_id->get_error_message() ) );
    } else {
        // Registrazione avvenuta con successo
        wp_send_json_success( array( 'message' => 'Registrazione effettuata con successo! Sarai reindirizzato alla pagina di login...', 'redirect_url' => wp_login_url() ) ); // Puoi reindirizzare dove vuoi
        // [Opzionale] - Potresti voler effettuare il login automatico dopo la registrazione:
        // wp_set_current_user( $user_id );
        // wp_set_auth_cookie( $user_id );
    }

    wp_die(); // Importante: Termina l'esecuzione di WordPress dopo la risposta AJAX
}
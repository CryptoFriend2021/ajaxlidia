<form id="salone-registrazione-form" class="salone-form" method="post">
    <p>
        <label for="salone-registrazione-username">Username:</label>
        <input type="text" name="username" id="salone-registrazione-username" required>
    </p>
    <p>
        <label for="salone-registrazione-email">Email:</label>
        <input type="email" name="email" id="salone-registrazione-email" required>
    </p>
    <p>
        <label for="salone-registrazione-password">Password:</label>
        <input type="password" name="password" id="salone-registrazione-password" required>
    </p>
    <p>
        <label for="salone-registrazione-password2">Ripeti Password:</label>
        <input type="password" name="password2" id="salone-registrazione-password2" required>
    </p>
    <p>
        <button type="submit">Registrati</button>
    </p>
    <div id="salone-registrazione-message" class="salone-form-message"></div>
</form>
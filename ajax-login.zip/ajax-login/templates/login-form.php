<form id="salone-login-form" class="salone-form" method="post">
    <p>
        <label for="salone-login-username">Username:</label>
        <input type="text" name="username" id="salone-login-username" required>
    </p>
    <p>
        <label for="salone-login-password">Password:</label>
        <input type="password" name="password" id="salone-login-password" required>
    </p>
    <p>
        <button type="submit">Login</button>
    </p>
    <div id="salone-login-message" class="salone-form-message"></div>
</form>